/*
 * Copyright 2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.cloud.ai.lynxe.runtime.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.cloud.ai.lynxe.config.LynxeProperties;
import com.alibaba.cloud.ai.lynxe.planning.PlanningFactory;
import com.alibaba.cloud.ai.lynxe.planning.service.PlanFinalizer;
import com.alibaba.cloud.ai.lynxe.runtime.entity.vo.ExecutionContext;
import com.alibaba.cloud.ai.lynxe.runtime.entity.vo.PlanExecutionResult;
import com.alibaba.cloud.ai.lynxe.runtime.entity.vo.PlanInterface;
import com.alibaba.cloud.ai.lynxe.runtime.entity.vo.RequestSource;
import com.alibaba.cloud.ai.lynxe.runtime.executor.PlanExecutorInterface;
import com.alibaba.cloud.ai.lynxe.runtime.executor.factory.PlanExecutorFactory;
import com.alibaba.cloud.ai.lynxe.workspace.conversation.service.MemoryService;

/**
 * Enhanced Planning Coordinator that uses PlanExecutorFactory to dynamically select the
 * appropriate executor based on plan type
 */
@Service
public class PlanningCoordinator {

	private static final Logger log = LoggerFactory.getLogger(PlanningCoordinator.class);

	private final PlanExecutorFactory planExecutorFactory;

	private final PlanFinalizer planFinalizer;

	private final MemoryService memoryService;

	private final LynxeProperties lynxeProperties;

	public PlanningCoordinator(PlanningFactory planningFactory, PlanExecutorFactory planExecutorFactory,
			PlanFinalizer planFinalizer, MemoryService memoryService, LynxeProperties lynxeProperties) {
		this.planExecutorFactory = planExecutorFactory;
		this.planFinalizer = planFinalizer;
		this.memoryService = memoryService;
		this.lynxeProperties = lynxeProperties;
	}

	/**
	 *
	 * key method Execute a plan directly using the provided plan interface
	 * @param plan The plan to execute
	 * @param rootPlanId The root plan ID for the execution context
	 * @param parentPlanId The ID of the parent plan (can be null for root plans)
	 * @param currentPlanId The current plan ID for execution
	 * @param toolcallId The ID of the tool call that triggered this plan execution
	 * @param requestSource Request source (HTTP_REQUEST, VUE_SIDEBAR, or VUE_DIALOG)
	 * @param uploadKey The upload key for file upload context (can be null)
	 * @param planDepth The depth of the plan in the execution hierarchy (0 for root, 1
	 * for first level, etc.)
	 * @param conversationId The conversation ID for the execution (can be null, will be
	 * generated if needed)
	 * @return A CompletableFuture that completes with the execution result
	 */
	public CompletableFuture<PlanExecutionResult> executeByPlan(PlanInterface plan, String rootPlanId,
			String parentPlanId, String currentPlanId, String toolcallId, RequestSource requestSource, String uploadKey,
			int planDepth, String conversationId) {
		return executeByPlan(plan, rootPlanId, parentPlanId, currentPlanId, toolcallId, requestSource, uploadKey,
				planDepth, conversationId, null);
	}

	/**
	 * Execute plan with optional recursive call chain tracking
	 * @param plan The plan to execute
	 * @param rootPlanId Root plan ID
	 * @param parentPlanId Parent plan ID
	 * @param currentPlanId Current plan ID
	 * @param toolcallId Tool call ID
	 * @param requestSource Request source
	 * @param uploadKey Upload key
	 * @param planDepth Plan depth
	 * @param conversationId Conversation ID
	 * @param recursiveCallChain Recursive call chain (list of planTemplateIds), can be
	 * null
	 * @return CompletableFuture that completes with plan execution result
	 */
	public CompletableFuture<PlanExecutionResult> executeByPlan(PlanInterface plan, String rootPlanId,
			String parentPlanId, String currentPlanId, String toolcallId, RequestSource requestSource, String uploadKey,
			int planDepth, String conversationId, List<String> recursiveCallChain) {
		try {
			log.info("Starting direct plan execution for plan: {} at depth: {}", plan.getCurrentPlanId(), planDepth);

			// Create execution context
			ExecutionContext context = new ExecutionContext();
			String title = plan.getTitle();
			context.setTitle(title);
			context.setCurrentPlanId(currentPlanId);
			context.setRootPlanId(rootPlanId);
			context.setPlan(plan);
			context.setPlanDepth(planDepth); // Set the plan depth
			// Set recursive call chain if provided
			if (recursiveCallChain != null) {
				context.setRecursiveCallChain(recursiveCallChain);
			}
			boolean isVueRequest = requestSource.isVueRequest();
			if (toolcallId == null && isVueRequest) {
				context.setNeedSummary(true);
				log.debug("Setting needSummary=true for planId: {}, toolcallId: {}, requestSource: {}", currentPlanId,
						toolcallId, requestSource);
			}
			else {
				// in sub plan or non-Vue request, we don't need to generate summary
				context.setNeedSummary(false);
				log.debug("Setting needSummary=false for planId: {}, toolcallId: {}, requestSource: {}", currentPlanId,
						toolcallId, requestSource);
			}
			// Set conversation ID (use provided or generate for VUE_DIALOG and
			// VUE_SIDEBAR requests)
			// Both VUE_DIALOG and VUE_SIDEBAR should use the same conversation memory
			// If conversation memory is disabled, always generate a new conversationId
			if (lynxeProperties != null && !lynxeProperties.getEnableConversationMemory()) {
				if (requestSource == RequestSource.VUE_DIALOG || requestSource == RequestSource.VUE_SIDEBAR) {
					String generatedConversationId = memoryService.generateConversationId();
					context.setConversationId(generatedConversationId);
					log.info("Conversation memory disabled, generated new conversation ID for {} request: {}",
							requestSource, generatedConversationId);
				}
				else {
					// For non-Vue requests, do not set conversationId
					log.debug("Conversation memory disabled, skipping conversationId for non-Vue request (source: {})",
							requestSource);
				}
			}
			else {
				// Conversation memory is enabled, use provided conversationId or generate
				// new one
				if (conversationId != null && !conversationId.trim().isEmpty()) {
					context.setConversationId(conversationId);
				}
				else if (requestSource == RequestSource.VUE_DIALOG || requestSource == RequestSource.VUE_SIDEBAR) {
					// Generate conversation ID for VUE_DIALOG and VUE_SIDEBAR requests
					// Both should use the same conversation memory
					String generatedConversationId = memoryService.generateConversationId();
					context.setConversationId(generatedConversationId);
					log.info("Generated conversation ID for {} request plan execution: {} (source: {})", requestSource,
							generatedConversationId, requestSource);
				}
				else {
					// For non-Vue requests (HTTP_REQUEST, internal calls), do not set
					// conversationId
					log.debug("No conversationId provided for non-Vue request, skipping conversationId (source: {})",
							requestSource);
				}
			}
			context.setUseConversation(true);
			context.setParentPlanId(parentPlanId);
			context.setToolCallId(toolcallId);
			context.setUploadKey(uploadKey);

			// Log toolcallId if provided
			if (toolcallId != null) {
				log.debug("Plan execution triggered by tool call: {}", toolcallId);
			}

			// Log uploadKey if provided
			if (uploadKey != null) {
				log.debug("Plan execution with upload key: {}", uploadKey);
			}

			// Execute the plan using PlanExecutorFactory
			PlanExecutorInterface executor = planExecutorFactory.createExecutor(plan);
			CompletableFuture<PlanExecutionResult> executionFuture = executor.executeAllStepsAsync(context);

			// Add post-execution processing
			return executionFuture.thenCompose(result -> {
				try {
					PlanExecutionResult processedResult = planFinalizer.handlePostExecution(context, result);
					return CompletableFuture.completedFuture(processedResult);
				}
				catch (Exception e) {
					log.error("Error during post-execution processing for plan: {}", context.getCurrentPlanId(), e);
					return CompletableFuture.failedFuture(e);
				}
			});

		}
		catch (Exception e) {
			log.error("Error during direct plan execution", e);
			PlanExecutionResult errorResult = new PlanExecutionResult();
			errorResult.setSuccess(false);
			errorResult.setErrorMessage("Direct plan execution failed: " + e.getMessage());
			return CompletableFuture.completedFuture(errorResult);
		}
	}

}
