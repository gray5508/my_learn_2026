/*
 * Copyright 2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.cloud.ai.lynxe.runtime.entity.vo;

import java.util.List;

import com.alibaba.cloud.ai.lynxe.agent.AgentState;
import com.alibaba.cloud.ai.lynxe.agent.BaseAgent;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The result of a single step execution
 */
public class ExecutionStep {

	/**
	 * Unique identifier for this execution step
	 */
	private String stepId;

	/**
	 * Constructor that requires a step ID
	 * @param stepId The step ID to use for this execution step
	 */
	public ExecutionStep(String stepId) {
		this.stepId = stepId;
	}

	public ExecutionStep() {

	}

	@JsonIgnore
	private Integer stepIndex;

	private String stepRequirement;

	private String agentName;

	private List<String> selectedToolKeys;

	private String modelName;

	@JsonIgnore
	private String result;

	@JsonIgnore
	private String errorMessage;

	@JsonIgnore
	private BaseAgent agent;

	private AgentState status;

	private String terminateColumns;

	public Integer getStepIndex() {
		return stepIndex;
	}

	public void setStepIndex(Integer stepIndex) {
		this.stepIndex = stepIndex;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@JsonIgnore
	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getTerminateColumns() {
		return terminateColumns;
	}

	public void setTerminateColumns(String terminateColumns) {
		this.terminateColumns = terminateColumns;
	}

	@JsonIgnore
	public AgentState getStatus() {
		return status != null ? status : (agent == null ? AgentState.NOT_STARTED : AgentState.NOT_STARTED);
	}

	public void setStatus(AgentState status) {
		this.status = status;
	}

	public void setAgent(BaseAgent agent) {
		this.agent = agent;
	}

	public BaseAgent getAgent() {
		return this.agent;
	}

	public String getStepRequirement() {
		return stepRequirement;
	}

	public void setStepRequirement(String stepRequirement) {
		this.stepRequirement = stepRequirement;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public List<String> getSelectedToolKeys() {
		return selectedToolKeys;
	}

	public void setSelectedToolKeys(List<String> selectedToolKeys) {
		this.selectedToolKeys = selectedToolKeys;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	@JsonIgnore
	public String getStepInStr() {
		String agentState = null;
		if (status != null) {
			agentState = status.toString();
		}
		else if (agent != null) {
			agentState = AgentState.NOT_STARTED.toString();
		}
		else {
			agentState = AgentState.NOT_STARTED.toString();
		}
		StringBuilder sb = new StringBuilder();
		sb.append(stepIndex);
		sb.append(". ");
		sb.append("[").append(agentState).append("]");
		sb.append(" ");
		sb.append(stepRequirement);

		return sb.toString();
	}

}
