// package com.alibaba.cloud.ai.lynxe.llm;

// import java.util.ArrayList;
// import java.util.Base64;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.concurrent.ConcurrentHashMap;
// import java.util.stream.Collectors;

// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.ai.chat.messages.AssistantMessage;
// import org.springframework.ai.chat.messages.MessageType;
// import org.springframework.ai.chat.messages.ToolResponseMessage;
// import org.springframework.ai.chat.messages.UserMessage;
// import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
// import org.springframework.ai.chat.metadata.ChatResponseMetadata;
// import org.springframework.ai.chat.metadata.DefaultUsage;
// import org.springframework.ai.chat.metadata.EmptyUsage;
// import org.springframework.ai.chat.metadata.RateLimit;
// import org.springframework.ai.chat.metadata.Usage;
// import org.springframework.ai.chat.model.ChatModel;
// import org.springframework.ai.chat.model.ChatResponse;
// import org.springframework.ai.chat.model.Generation;
// import org.springframework.ai.chat.model.MessageAggregator;
// import org.springframework.ai.chat.observation.ChatModelObservationContext;
// import org.springframework.ai.chat.observation.ChatModelObservationConvention;
// import org.springframework.ai.chat.observation.ChatModelObservationDocumentation;
// import org.springframework.ai.chat.observation.DefaultChatModelObservationConvention;
// import org.springframework.ai.chat.prompt.ChatOptions;
// import org.springframework.ai.chat.prompt.Prompt;
// import org.springframework.ai.content.Media;
// import org.springframework.ai.model.ModelOptionsUtils;
// import org.springframework.ai.model.tool.DefaultToolExecutionEligibilityPredicate;
// import org.springframework.ai.model.tool.ToolCallingChatOptions;
// import org.springframework.ai.model.tool.ToolCallingManager;
// import org.springframework.ai.model.tool.ToolExecutionEligibilityPredicate;
// import org.springframework.ai.model.tool.ToolExecutionResult;
// import org.springframework.ai.model.tool.internal.ToolCallReactiveContextHolder;
// import org.springframework.ai.openai.OpenAiChatOptions;
// import org.springframework.ai.openai.api.OpenAiApi;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletion;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletion.Choice;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionMessage;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionMessage.AudioOutput;
// import
// org.springframework.ai.openai.api.OpenAiApi.ChatCompletionMessage.ChatCompletionFunction;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionMessage.MediaContent;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionMessage.ToolCall;
// import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionRequest;
// import org.springframework.ai.openai.api.common.OpenAiApiConstants;
// import org.springframework.ai.openai.metadata.support.OpenAiResponseHeaderExtractor;
// import org.springframework.ai.retry.RetryUtils;
// import org.springframework.ai.support.UsageCalculator;
// import org.springframework.ai.tool.definition.ToolDefinition;
// import org.springframework.core.io.ByteArrayResource;
// import org.springframework.core.io.Resource;
// import org.springframework.http.ResponseEntity;
// import org.springframework.retry.support.RetryTemplate;
// import org.springframework.util.Assert;
// import org.springframework.util.CollectionUtils;
// import org.springframework.util.MimeType;
// import org.springframework.util.MimeTypeUtils;
// import org.springframework.util.MultiValueMap;
// import org.springframework.util.StringUtils;

// import io.micrometer.observation.Observation;
// import io.micrometer.observation.ObservationRegistry;
// import io.micrometer.observation.contextpropagation.ObservationThreadLocalAccessor;
// import reactor.core.publisher.Flux;
// import reactor.core.publisher.Mono;
// import reactor.core.scheduler.Schedulers;

// /**
// * Custom ChatModel implementation that supports incremental tool call streaming
// * using Spring AI's existing merging logic.
// *
// * <p>Key features:
// * <ul>
// * <li>Uses OpenAiApi.chatCompletionStream() directly, which already handles
// merging</li>
// * <li>Logs merged chunks with complete tool call arguments</li>
// * <li>Converts merged chunks to ChatResponse using Spring AI patterns</li>
// * <li>Preserves Spring AI's standard behavior while providing visibility</li>
// * </ul>
// *
// * <p>Note: This implementation relies on Spring AI's built-in merging logic in
// * OpenAiApi.chatCompletionStream(), which uses windowUntil + reduce + merge to
// * combine incremental tool call arguments. The chunks received are already merged.
// *
// * @author Lynxe Team
// */
// public class IncrementalToolCallChatModel implements ChatModel {

// private static final Logger logger =
// LoggerFactory.getLogger(IncrementalToolCallChatModel.class);

// private static final ChatModelObservationConvention DEFAULT_OBSERVATION_CONVENTION =
// new DefaultChatModelObservationConvention();

// private static final ToolCallingManager DEFAULT_TOOL_CALLING_MANAGER =
// ToolCallingManager.builder().build();

// /**
// * The default options used for the chat completion requests.
// */
// private final OpenAiChatOptions defaultOptions;

// /**
// * The retry template used to retry the OpenAI API calls.
// */
// private final RetryTemplate retryTemplate;

// /**
// * Low-level access to the OpenAI API.
// */
// private final OpenAiApi openAiApi;

// /**
// * Observation registry used for instrumentation.
// */
// private final ObservationRegistry observationRegistry;

// private final ToolCallingManager toolCallingManager;

// /**
// * The tool execution eligibility predicate used to determine if a tool can be
// * executed.
// */
// private final ToolExecutionEligibilityPredicate toolExecutionEligibilityPredicate;

// /**
// * Conventions to use for generating observations.
// */
// private ChatModelObservationConvention observationConvention =
// DEFAULT_OBSERVATION_CONVENTION;

// public IncrementalToolCallChatModel(OpenAiApi openAiApi, OpenAiChatOptions
// defaultOptions, ToolCallingManager toolCallingManager,
// RetryTemplate retryTemplate, ObservationRegistry observationRegistry) {
// this(openAiApi, defaultOptions, toolCallingManager, retryTemplate, observationRegistry,
// new DefaultToolExecutionEligibilityPredicate());
// }

// public IncrementalToolCallChatModel(OpenAiApi openAiApi, OpenAiChatOptions
// defaultOptions, ToolCallingManager toolCallingManager,
// RetryTemplate retryTemplate, ObservationRegistry observationRegistry,
// ToolExecutionEligibilityPredicate toolExecutionEligibilityPredicate) {
// Assert.notNull(openAiApi, "openAiApi cannot be null");
// Assert.notNull(defaultOptions, "defaultOptions cannot be null");
// Assert.notNull(toolCallingManager, "toolCallingManager cannot be null");
// Assert.notNull(retryTemplate, "retryTemplate cannot be null");
// Assert.notNull(observationRegistry, "observationRegistry cannot be null");
// Assert.notNull(toolExecutionEligibilityPredicate, "toolExecutionEligibilityPredicate
// cannot be null");
// this.openAiApi = openAiApi;
// this.defaultOptions = defaultOptions;
// this.toolCallingManager = toolCallingManager;
// this.retryTemplate = retryTemplate;
// this.observationRegistry = observationRegistry;
// this.toolExecutionEligibilityPredicate = toolExecutionEligibilityPredicate;
// }

// @Override
// public ChatResponse call(Prompt prompt) {
// // Before moving any further, build the final request Prompt,
// // merging runtime and default options.
// Prompt requestPrompt = buildRequestPrompt(prompt);
// return this.internalCall(requestPrompt, null);
// }

// public ChatResponse internalCall(Prompt prompt, ChatResponse previousChatResponse) {

// ChatCompletionRequest request = createRequest(prompt, false);

// ChatModelObservationContext observationContext = ChatModelObservationContext.builder()
// .prompt(prompt)
// .provider(OpenAiApiConstants.PROVIDER_NAME)
// .build();

// ChatResponse response = ChatModelObservationDocumentation.CHAT_MODEL_OPERATION
// .observation(this.observationConvention, DEFAULT_OBSERVATION_CONVENTION, () ->
// observationContext,
// this.observationRegistry)
// .observe(() -> {

// ResponseEntity<ChatCompletion> completionEntity = this.retryTemplate
// .execute(ctx -> this.openAiApi.chatCompletionEntity(request,
// getAdditionalHttpHeaders(prompt)));

// var chatCompletion = completionEntity.getBody();

// if (chatCompletion == null) {
// logger.warn("No chat completion returned for prompt: {}", prompt);
// return new ChatResponse(List.of());
// }

// List<Choice> choices = chatCompletion.choices();
// if (choices == null) {
// logger.warn("No choices returned for prompt: {}", prompt);
// return new ChatResponse(List.of());
// }

// 			// @formatter:off
// 				List<Generation> generations = choices.stream().map(choice -> {
// 					Map<String, Object> metadata = Map.of(
// 							"id", chatCompletion.id() != null ? chatCompletion.id() : "",
// 							"role", choice.message().role() != null ? choice.message().role().name() : "",
// 							"index", choice.index() != null ? choice.index() : 0,
// 							"finishReason", getFinishReasonJson(choice.finishReason()),
// 							"refusal", StringUtils.hasText(choice.message().refusal()) ? choice.message().refusal() : "",
// 							"annotations", choice.message().annotations() != null ? choice.message().annotations() : List.of(Map.of()));
// 					return buildGeneration(choice, metadata, request);
// 				}).toList();
// 				// @formatter:on

// RateLimit rateLimit =
// OpenAiResponseHeaderExtractor.extractAiResponseHeaders(completionEntity);

// // Current usage
// OpenAiApi.Usage usage = chatCompletion.usage();
// Usage currentChatResponseUsage = usage != null ? getDefaultUsage(usage) : new
// EmptyUsage();
// Usage accumulatedUsage = UsageCalculator.getCumulativeUsage(currentChatResponseUsage,
// previousChatResponse);
// ChatResponse chatResponse = new ChatResponse(generations,
// from(chatCompletion, rateLimit, accumulatedUsage));

// observationContext.setResponse(chatResponse);

// return chatResponse;

// });

// if (this.toolExecutionEligibilityPredicate.isToolExecutionRequired(prompt.getOptions(),
// response)) {
// var toolExecutionResult = this.toolCallingManager.executeToolCalls(prompt, response);
// if (toolExecutionResult.returnDirect()) {
// // Return tool execution result directly to the client.
// return ChatResponse.builder()
// .from(response)
// .generations(ToolExecutionResult.buildGenerations(toolExecutionResult))
// .build();
// }
// else {
// // Send the tool execution result back to the model.
// return this.internalCall(new Prompt(toolExecutionResult.conversationHistory(),
// prompt.getOptions()),
// response);
// }
// }

// return response;
// }

// @Override
// public Flux<ChatResponse> stream(Prompt prompt) {
// // Before moving any further, build the final request Prompt,
// // merging runtime and default options.
// Prompt requestPrompt = buildRequestPrompt(prompt);
// return internalStream(requestPrompt, null);
// }

// public Flux<ChatResponse> internalStream(Prompt prompt, ChatResponse
// previousChatResponse) {
// return Flux.deferContextual(contextView -> {
// ChatCompletionRequest request = createRequest(prompt, true);

// if (request.outputModalities() != null
// && request.outputModalities().contains(OpenAiApi.OutputModality.AUDIO)) {
// logger.warn("Audio output is not supported for streaming requests. Removing audio
// output.");
// throw new IllegalArgumentException("Audio output is not supported for streaming
// requests.");
// }

// if (request.audioParameters() != null) {
// logger.warn("Audio parameters are not supported for streaming requests. Removing audio
// parameters.");
// throw new IllegalArgumentException("Audio parameters are not supported for streaming
// requests.");
// }

// Flux<OpenAiApi.ChatCompletionChunk> completionChunks =
// this.openAiApi.chatCompletionStream(request,
// getAdditionalHttpHeaders(prompt));

// // Log each chunk with detailed information using warn level
// completionChunks = completionChunks.doOnNext(chunk -> {
// logChunk(chunk);
// });

// // For chunked responses, only the first chunk contains the choice role.
// // The rest of the chunks with same ID share the same role.
// ConcurrentHashMap<String, String> roleMap = new ConcurrentHashMap<>();

// final ChatModelObservationContext observationContext =
// ChatModelObservationContext.builder()
// .prompt(prompt)
// .provider(OpenAiApiConstants.PROVIDER_NAME)
// .build();

// Observation observation =
// ChatModelObservationDocumentation.CHAT_MODEL_OPERATION.observation(
// this.observationConvention, DEFAULT_OBSERVATION_CONVENTION, () -> observationContext,
// this.observationRegistry);

// observation.parentObservation(contextView.getOrDefault(ObservationThreadLocalAccessor.KEY,
// null)).start();

// // Convert the ChatCompletionChunk into a ChatCompletion to be able to reuse
// // the function call handling logic.
// Flux<ChatResponse> chatResponse = completionChunks.map(this::chunkToChatCompletion)
// .switchMap(chatCompletion -> Mono.just(chatCompletion).map(chatCompletion2 -> {
// try {
// // If an id is not provided, set to "NO_ID" (for compatible APIs).
// String id = chatCompletion2.id() == null ? "NO_ID" : chatCompletion2.id();

// 						List<Generation> generations = chatCompletion2.choices().stream().map(choice -> { // @formatter:off
// 							if (choice.message().role() != null) {
// 								roleMap.putIfAbsent(id, choice.message().role().name());
// 							}
// 							Map<String, Object> metadata = Map.of(
// 									"id", id,
// 									"role", roleMap.getOrDefault(id, ""),
// 									"index", choice.index() != null ? choice.index() : 0,
// 									"finishReason", getFinishReasonJson(choice.finishReason()),
// 									"refusal", StringUtils.hasText(choice.message().refusal()) ? choice.message().refusal() : "",
// 									"annotations", choice.message().annotations() != null ? choice.message().annotations() : List.of(),
// 									"reasoningContent", choice.message().reasoningContent() != null ? choice.message().reasoningContent() : "");
// 							return buildGeneration(choice, metadata, request);
// 						}).toList();
// 						// @formatter:on
// OpenAiApi.Usage usage = chatCompletion2.usage();
// Usage currentChatResponseUsage = usage != null ? getDefaultUsage(usage) : new
// EmptyUsage();
// Usage accumulatedUsage = UsageCalculator.getCumulativeUsage(currentChatResponseUsage,
// previousChatResponse);
// return new ChatResponse(generations, from(chatCompletion2, null, accumulatedUsage));
// }
// catch (Exception e) {
// logger.error("Error processing chat completion", e);
// return new ChatResponse(List.of());
// }
// // When in stream mode and enabled to include the usage, the OpenAI
// // Chat completion response would have the usage set only in its
// // final response. Hence, the following overlapping buffer is
// // created to store both the current and the subsequent response
// // to accumulate the usage from the subsequent response.
// }))
// .buffer(2, 1)
// .map(bufferList -> {
// ChatResponse firstResponse = bufferList.get(0);
// if (request.streamOptions() != null && request.streamOptions().includeUsage()) {
// if (bufferList.size() == 2) {
// ChatResponse secondResponse = bufferList.get(1);
// if (secondResponse != null && secondResponse.getMetadata() != null) {
// // This is the usage from the final Chat response for a
// // given Chat request.
// Usage usage = secondResponse.getMetadata().getUsage();
// if (!UsageCalculator.isEmpty(usage)) {
// // Store the usage from the final response to the
// // penultimate response for accumulation.
// return new ChatResponse(firstResponse.getResults(),
// from(firstResponse.getMetadata(), usage));
// }
// }
// }
// }
// return firstResponse;
// });

// 			// @formatter:off
// 			Flux<ChatResponse> flux = chatResponse.flatMap(response -> {
// 				if (this.toolExecutionEligibilityPredicate.isToolExecutionRequired(prompt.getOptions(), response)) {
// 					// FIXME: bounded elastic needs to be used since tool calling
// 					//  is currently only synchronous
// 					return Flux.deferContextual(ctx -> {
// 						ToolExecutionResult toolExecutionResult;
// 						try {
// 							ToolCallReactiveContextHolder.setContext(ctx);
// 							toolExecutionResult = this.toolCallingManager.executeToolCalls(prompt, response);
// 						}
// 						finally {
// 							ToolCallReactiveContextHolder.clearContext();
// 						}
// 						if (toolExecutionResult.returnDirect()) {
// 							// Return tool execution result directly to the client.
// 							return Flux.just(ChatResponse.builder().from(response)
// 									.generations(ToolExecutionResult.buildGenerations(toolExecutionResult))
// 									.build());
// 						}
// 						else {
// 							// Send the tool execution result back to the model.
// 							return this.internalStream(new Prompt(toolExecutionResult.conversationHistory(), prompt.getOptions()),
// 									response);
// 						}
// 					}).subscribeOn(Schedulers.boundedElastic());
// 				}
// 				else {
// 					return Flux.just(response);
// 				}
// 			})
// 			.doOnError(observation::error)
// 			.doFinally(s -> observation.stop())
// 			.contextWrite(ctx -> ctx.put(ObservationThreadLocalAccessor.KEY, observation));
// 			// @formatter:on

// return new MessageAggregator().aggregate(flux, observationContext::setResponse);

// });
// }

// private MultiValueMap<String, String> getAdditionalHttpHeaders(Prompt prompt) {

// Map<String, String> headers = new HashMap<>(this.defaultOptions.getHttpHeaders());
// if (prompt.getOptions() != null && prompt.getOptions() instanceof OpenAiChatOptions
// chatOptions) {
// headers.putAll(chatOptions.getHttpHeaders());
// }
// return CollectionUtils.toMultiValueMap(
// headers.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e ->
// List.of(e.getValue()))));
// }

// private Generation buildGeneration(Choice choice, Map<String, Object> metadata,
// ChatCompletionRequest request) {
// List<AssistantMessage.ToolCall> toolCalls = choice.message().toolCalls() == null ?
// List.of()
// : choice.message()
// .toolCalls()
// .stream()
// .map(toolCall -> new AssistantMessage.ToolCall(toolCall.id(), "function",
// toolCall.function().name(), toolCall.function().arguments()))
// .toList();

// var generationMetadataBuilder = ChatGenerationMetadata.builder()
// .finishReason(getFinishReasonJson(choice.finishReason()));

// List<Media> media = new ArrayList<>();
// String textContent = choice.message().content();
// var audioOutput = choice.message().audioOutput();
// if (audioOutput != null && StringUtils.hasText(audioOutput.data()) &&
// request.audioParameters() != null) {
// String mimeType = String.format("audio/%s",
// request.audioParameters().format().name().toLowerCase());
// byte[] audioData = Base64.getDecoder().decode(audioOutput.data());
// Resource resource = new ByteArrayResource(audioData);
// Media.builder().mimeType(MimeTypeUtils.parseMimeType(mimeType)).data(resource).id(audioOutput.id()).build();
// media.add(Media.builder()
// .mimeType(MimeTypeUtils.parseMimeType(mimeType))
// .data(resource)
// .id(audioOutput.id())
// .build());
// if (!StringUtils.hasText(textContent)) {
// textContent = audioOutput.transcript();
// }
// generationMetadataBuilder.metadata("audioId", audioOutput.id());
// generationMetadataBuilder.metadata("audioExpiresAt", audioOutput.expiresAt());
// }

// if (Boolean.TRUE.equals(request.logprobs())) {
// generationMetadataBuilder.metadata("logprobs", choice.logprobs());
// }

// var assistantMessage = AssistantMessage.builder()
// .content(textContent)
// .properties(metadata)
// .toolCalls(toolCalls)
// .media(media)
// .build();
// return new Generation(assistantMessage, generationMetadataBuilder.build());
// }

// private String getFinishReasonJson(OpenAiApi.ChatCompletionFinishReason finishReason) {
// if (finishReason == null) {
// return "";
// }
// // Return enum name for backward compatibility
// return finishReason.name();
// }

// private ChatResponseMetadata from(OpenAiApi.ChatCompletion result, RateLimit rateLimit,
// Usage usage) {
// Assert.notNull(result, "OpenAI ChatCompletionResult must not be null");
// var builder = ChatResponseMetadata.builder()
// .id(result.id() != null ? result.id() : "")
// .usage(usage)
// .model(result.model() != null ? result.model() : "")
// .keyValue("created", result.created() != null ? result.created() : 0L)
// .keyValue("system-fingerprint", result.systemFingerprint() != null ?
// result.systemFingerprint() : "");
// if (rateLimit != null) {
// builder.rateLimit(rateLimit);
// }
// return builder.build();
// }

// private ChatResponseMetadata from(ChatResponseMetadata chatResponseMetadata, Usage
// usage) {
// Assert.notNull(chatResponseMetadata, "OpenAI ChatResponseMetadata must not be null");
// var builder = ChatResponseMetadata.builder()
// .id(chatResponseMetadata.getId() != null ? chatResponseMetadata.getId() : "")
// .usage(usage)
// .model(chatResponseMetadata.getModel() != null ? chatResponseMetadata.getModel() : "");
// if (chatResponseMetadata.getRateLimit() != null) {
// builder.rateLimit(chatResponseMetadata.getRateLimit());
// }
// return builder.build();
// }

// /**
// * Log chunk information with detailed parsing
// * Uses warn level for visibility
// */
// private void logChunk(OpenAiApi.ChatCompletionChunk chunk) {
// if (chunk == null) {
// logger.warn("📦 Chunk: null");
// return;
// }

// String chunkId = chunk.id() != null ? chunk.id() : "NO_ID";
// String model = chunk.model() != null ? chunk.model() : "NO_MODEL";
// Long created = chunk.created();
// String systemFingerprint = chunk.systemFingerprint();
// OpenAiApi.Usage usage = chunk.usage();

// logger.warn("📦 Chunk [id={}, model={}, created={}, systemFingerprint={}]",
// chunkId, model, created, systemFingerprint);

// // Log usage if available
// if (usage != null) {
// logger.warn(" └─ Usage: promptTokens={}, completionTokens={}, totalTokens={}",
// usage.promptTokens(), usage.completionTokens(), usage.totalTokens());
// }

// // Parse choices
// if (CollectionUtils.isEmpty(chunk.choices())) {
// logger.warn(" └─ Choices: (empty)");
// return;
// }

// logger.warn(" └─ Choices: {} choice(s)", chunk.choices().size());

// for (int i = 0; i < chunk.choices().size(); i++) {
// OpenAiApi.ChatCompletionChunk.ChunkChoice choice = chunk.choices().get(i);
// logChunkChoice(choice, i);
// }
// }

// /**
// * Log detailed information about a chunk choice
// */
// private void logChunkChoice(OpenAiApi.ChatCompletionChunk.ChunkChoice choice, int
// index) {
// if (choice == null) {
// logger.warn(" └─ Choice[{}]: null", index);
// return;
// }

// Integer choiceIndex = choice.index();
// OpenAiApi.ChatCompletionFinishReason finishReason = choice.finishReason();
// OpenAiApi.ChatCompletionMessage delta = choice.delta();

// logger.warn(" └─ Choice[{}]: index={}, finishReason={}",
// index, choiceIndex, finishReason != null ? finishReason.name() : "null");

// if (delta == null) {
// logger.warn(" └─ Delta: null");
// return;
// }

// // Log role
// if (delta.role() != null) {
// logger.warn(" └─ Role: {}", delta.role().name());
// }

// // Log content
// if (StringUtils.hasText(delta.content())) {
// logger.warn(" └─ Content: '{}'", delta.content());
// }

// // Log tool calls (these are already merged)
// if (!CollectionUtils.isEmpty(delta.toolCalls())) {
// logger.warn(" └─ Tool Calls: {} tool call(s)", delta.toolCalls().size());

// for (int j = 0; j < delta.toolCalls().size(); j++) {
// OpenAiApi.ChatCompletionMessage.ToolCall toolCall = delta.toolCalls().get(j);
// logToolCall(toolCall, j);
// }
// }

// // Log refusal if present
// if (StringUtils.hasText(delta.refusal())) {
// logger.warn(" └─ Refusal: '{}'", delta.refusal());
// }

// // Log annotations if present
// if (delta.annotations() != null && !delta.annotations().isEmpty()) {
// logger.warn(" └─ Annotations: {} annotation(s)", delta.annotations().size());
// }

// // Log reasoning content if present
// if (StringUtils.hasText(delta.reasoningContent())) {
// logger.warn(" └─ Reasoning Content: '{}'", delta.reasoningContent());
// }
// }

// /**
// * Log detailed information about a tool call
// */
// private void logToolCall(OpenAiApi.ChatCompletionMessage.ToolCall toolCall, int index)
// {
// if (toolCall == null) {
// logger.warn(" └─ ToolCall[{}]: null", index);
// return;
// }

// String toolCallId = toolCall.id() != null ? toolCall.id() : "(no id)";
// String toolCallType = toolCall.type() != null ? toolCall.type() : "(no type)";
// Integer toolCallIndex = toolCall.index();
// OpenAiApi.ChatCompletionMessage.ChatCompletionFunction function = toolCall.function();

// logger.warn(" └─ ToolCall[{}]: id={}, type={}, index={}",
// index, toolCallId, toolCallType, toolCallIndex);

// if (function == null) {
// logger.warn(" └─ Function: null");
// return;
// }

// String functionName = function.name() != null ? function.name() : "(no name)";
// String arguments = function.arguments() != null ? function.arguments() : "";

// logger.warn(" └─ Function: name='{}'", functionName);

// if (StringUtils.hasText(arguments)) {
// logger.warn(" └─ Arguments (MERGED - complete): '{}'", arguments);
// logger.warn(" └─ Arguments length: {} chars", arguments.length());
// }
// else {
// logger.warn(" └─ Arguments: (empty)");
// }
// }

// /**
// * Convert the ChatCompletionChunk into a ChatCompletion. The Usage is set to null.
// * @param chunk the ChatCompletionChunk to convert
// * @return the ChatCompletion
// */
// private OpenAiApi.ChatCompletion chunkToChatCompletion(OpenAiApi.ChatCompletionChunk
// chunk) {
// List<Choice> choices = chunk.choices()
// .stream()
// .map(chunkChoice -> new Choice(chunkChoice.finishReason(), chunkChoice.index(),
// chunkChoice.delta(),
// chunkChoice.logprobs()))
// .toList();

// return new OpenAiApi.ChatCompletion(chunk.id(), choices, chunk.created(),
// chunk.model(), chunk.serviceTier(),
// chunk.systemFingerprint(), "chat.completion", chunk.usage());
// }

// private DefaultUsage getDefaultUsage(OpenAiApi.Usage usage) {
// return new DefaultUsage(usage.promptTokens(), usage.completionTokens(),
// usage.totalTokens(), usage);
// }

// Prompt buildRequestPrompt(Prompt prompt) {
// // Process runtime options
// OpenAiChatOptions runtimeOptions = null;
// if (prompt.getOptions() != null) {
// if (prompt.getOptions() instanceof ToolCallingChatOptions toolCallingChatOptions) {
// runtimeOptions = ModelOptionsUtils.copyToTarget(toolCallingChatOptions,
// ToolCallingChatOptions.class,
// OpenAiChatOptions.class);
// }
// else {
// runtimeOptions = ModelOptionsUtils.copyToTarget(prompt.getOptions(), ChatOptions.class,
// OpenAiChatOptions.class);
// }
// }

// // Define request options by merging runtime options and default options
// OpenAiChatOptions requestOptions = ModelOptionsUtils.merge(runtimeOptions,
// this.defaultOptions,
// OpenAiChatOptions.class);

// // Merge @JsonIgnore-annotated options explicitly since they are ignored by
// // Jackson, used by ModelOptionsUtils.
// if (runtimeOptions != null) {
// if (runtimeOptions.getTopK() != null) {
// logger.warn("The topK option is not supported by OpenAI chat models. Ignoring.");
// }

// requestOptions.setHttpHeaders(
// mergeHttpHeaders(runtimeOptions.getHttpHeaders(),
// this.defaultOptions.getHttpHeaders()));
// requestOptions.setInternalToolExecutionEnabled(
// ModelOptionsUtils.mergeOption(runtimeOptions.getInternalToolExecutionEnabled(),
// this.defaultOptions.getInternalToolExecutionEnabled()));
// requestOptions.setToolNames(ToolCallingChatOptions.mergeToolNames(runtimeOptions.getToolNames(),
// this.defaultOptions.getToolNames()));
// requestOptions.setToolCallbacks(ToolCallingChatOptions.mergeToolCallbacks(runtimeOptions.getToolCallbacks(),
// this.defaultOptions.getToolCallbacks()));
// requestOptions.setToolContext(ToolCallingChatOptions.mergeToolContext(runtimeOptions.getToolContext(),
// this.defaultOptions.getToolContext()));
// requestOptions
// .setExtraBody(mergeExtraBody(runtimeOptions.getExtraBody(),
// this.defaultOptions.getExtraBody()));
// }
// else {
// requestOptions.setHttpHeaders(this.defaultOptions.getHttpHeaders());
// requestOptions.setInternalToolExecutionEnabled(this.defaultOptions.getInternalToolExecutionEnabled());
// requestOptions.setToolNames(this.defaultOptions.getToolNames());
// requestOptions.setToolCallbacks(this.defaultOptions.getToolCallbacks());
// requestOptions.setToolContext(this.defaultOptions.getToolContext());
// requestOptions.setExtraBody(this.defaultOptions.getExtraBody());
// }

// ToolCallingChatOptions.validateToolCallbacks(requestOptions.getToolCallbacks());

// return new Prompt(prompt.getInstructions(), requestOptions);
// }

// private Map<String, String> mergeHttpHeaders(Map<String, String> runtimeHttpHeaders,
// Map<String, String> defaultHttpHeaders) {
// var mergedHttpHeaders = new HashMap<>(defaultHttpHeaders);
// mergedHttpHeaders.putAll(runtimeHttpHeaders);
// return mergedHttpHeaders;
// }

// private Map<String, Object> mergeExtraBody(Map<String, Object> runtimeExtraBody,
// Map<String, Object> defaultExtraBody) {
// if (defaultExtraBody == null && runtimeExtraBody == null) {
// return null;
// }
// var merged = new HashMap<String, Object>();
// if (defaultExtraBody != null) {
// merged.putAll(defaultExtraBody);
// }
// if (runtimeExtraBody != null) {
// merged.putAll(runtimeExtraBody); // runtime overrides default
// }
// return merged.isEmpty() ? null : merged;
// }

// /**
// * Accessible for testing.
// */
// ChatCompletionRequest createRequest(Prompt prompt, boolean stream) {

// List<ChatCompletionMessage> chatCompletionMessages =
// prompt.getInstructions().stream().map(message -> {
// if (message.getMessageType() == MessageType.USER || message.getMessageType() ==
// MessageType.SYSTEM) {
// Object content = message.getText();
// if (message instanceof UserMessage userMessage) {
// if (!CollectionUtils.isEmpty(userMessage.getMedia())) {
// List<MediaContent> contentList = new ArrayList<>(List.of(new
// MediaContent(message.getText())));

// contentList.addAll(userMessage.getMedia().stream().map(this::mapToMediaContent).toList());

// content = contentList;
// }
// }

// return List.of(new ChatCompletionMessage(content,
// ChatCompletionMessage.Role.valueOf(message.getMessageType().name())));
// }
// else if (message.getMessageType() == MessageType.ASSISTANT) {
// var assistantMessage = (AssistantMessage) message;
// List<ToolCall> toolCalls = null;
// if (!CollectionUtils.isEmpty(assistantMessage.getToolCalls())) {
// toolCalls = assistantMessage.getToolCalls().stream().map(toolCall -> {
// var function = new ChatCompletionFunction(toolCall.name(), toolCall.arguments());
// return new ToolCall(toolCall.id(), toolCall.type(), function);
// }).toList();
// }
// AudioOutput audioOutput = null;
// if (!CollectionUtils.isEmpty(assistantMessage.getMedia())) {
// Assert.isTrue(assistantMessage.getMedia().size() == 1,
// "Only one media content is supported for assistant messages");
// audioOutput = new AudioOutput(assistantMessage.getMedia().get(0).getId(), null, null,
// null);

// }
// return List.of(new ChatCompletionMessage(assistantMessage.getText(),
// ChatCompletionMessage.Role.ASSISTANT, null, null, toolCalls, null, audioOutput, null,
// null));
// }
// else if (message.getMessageType() == MessageType.TOOL) {
// ToolResponseMessage toolMessage = (ToolResponseMessage) message;

// toolMessage.getResponses()
// .forEach(response -> Assert.isTrue(response.id() != null, "ToolResponseMessage must
// have an id"));
// return toolMessage.getResponses()
// .stream()
// .map(tr -> new ChatCompletionMessage(tr.responseData(),
// ChatCompletionMessage.Role.TOOL, tr.name(),
// tr.id(), null, null, null, null, null))
// .toList();
// }
// else {
// throw new IllegalArgumentException("Unsupported message type: " +
// message.getMessageType());
// }
// }).flatMap(List::stream).toList();

// ChatCompletionRequest request = new ChatCompletionRequest(chatCompletionMessages,
// stream);

// OpenAiChatOptions requestOptions = (OpenAiChatOptions) prompt.getOptions();
// request = ModelOptionsUtils.merge(requestOptions, request,
// ChatCompletionRequest.class);

// // Add the tool definitions to the request's tools parameter.
// List<ToolDefinition> toolDefinitions =
// this.toolCallingManager.resolveToolDefinitions(requestOptions);
// if (!CollectionUtils.isEmpty(toolDefinitions)) {
// request = ModelOptionsUtils.merge(
// OpenAiChatOptions.builder().tools(this.getFunctionTools(toolDefinitions)).build(),
// request,
// ChatCompletionRequest.class);
// }

// // Remove `streamOptions` from the request if it is not a streaming request
// if (request.streamOptions() != null && !stream) {
// logger.warn("Removing streamOptions from the request as it is not a streaming
// request!");
// request = request.streamOptions(null);
// }

// return request;
// }

// private MediaContent mapToMediaContent(Media media) {
// var mimeType = media.getMimeType();
// if (MimeTypeUtils.parseMimeType("audio/mp3").equals(mimeType)) {
// return new MediaContent(
// new MediaContent.InputAudio(fromAudioData(media.getData()),
// MediaContent.InputAudio.Format.MP3));
// }
// if (MimeTypeUtils.parseMimeType("audio/wav").equals(mimeType)) {
// return new MediaContent(
// new MediaContent.InputAudio(fromAudioData(media.getData()),
// MediaContent.InputAudio.Format.WAV));
// }
// if (MimeTypeUtils.parseMimeType("application/pdf").equals(mimeType)) {
// return new MediaContent(new MediaContent.InputFile(media.getName(),
// this.fromMediaData(media.getMimeType(), media.getData())));
// }
// else {
// return new MediaContent(
// new MediaContent.ImageUrl(this.fromMediaData(media.getMimeType(), media.getData())));
// }
// }

// private String fromAudioData(Object audioData) {
// if (audioData instanceof byte[] bytes) {
// return Base64.getEncoder().encodeToString(bytes);
// }
// throw new IllegalArgumentException("Unsupported audio data type: " +
// audioData.getClass().getSimpleName());
// }

// private String fromMediaData(MimeType mimeType, Object mediaContentData) {
// if (mediaContentData instanceof byte[] bytes) {
// // Assume the bytes are an image. So, convert the bytes to a base64 encoded
// // following the prefix pattern.
// return String.format("data:%s;base64,%s", mimeType.toString(),
// Base64.getEncoder().encodeToString(bytes));
// }
// else if (mediaContentData instanceof String text) {
// // Assume the text is a URLs or a base64 encoded image prefixed by the user.
// return text;
// }
// else {
// throw new IllegalArgumentException(
// "Unsupported media data type: " + mediaContentData.getClass().getSimpleName());
// }
// }

// private List<OpenAiApi.FunctionTool> getFunctionTools(List<ToolDefinition>
// toolDefinitions) {
// return toolDefinitions.stream().map(toolDefinition -> {
// var function = new OpenAiApi.FunctionTool.Function(toolDefinition.description(),
// toolDefinition.name(),
// toolDefinition.inputSchema());
// return new OpenAiApi.FunctionTool(function);
// }).toList();
// }

// @Override
// public ChatOptions getDefaultOptions() {
// return OpenAiChatOptions.fromOptions(this.defaultOptions);
// }

// @Override
// public String toString() {
// return "IncrementalToolCallChatModel [defaultOptions=" + this.defaultOptions + "]";
// }

// /**
// * Use the provided convention for reporting observation data
// * @param observationConvention The provided convention
// */
// public void setObservationConvention(ChatModelObservationConvention
// observationConvention) {
// Assert.notNull(observationConvention, "observationConvention cannot be null");
// this.observationConvention = observationConvention;
// }

// public static Builder builder() {
// return new Builder();
// }

// /**
// * Returns a builder pre-populated with the current configuration for mutation.
// */
// public Builder mutate() {
// return new Builder(this);
// }

// @Override
// public IncrementalToolCallChatModel clone() {
// return this.mutate().build();
// }

// public static final class Builder {

// // Copy constructor for mutate()
// public Builder(IncrementalToolCallChatModel model) {
// this.openAiApi = model.openAiApi;
// this.defaultOptions = model.defaultOptions;
// this.toolCallingManager = model.toolCallingManager;
// this.toolExecutionEligibilityPredicate = model.toolExecutionEligibilityPredicate;
// this.retryTemplate = model.retryTemplate;
// this.observationRegistry = model.observationRegistry;
// }

// private OpenAiApi openAiApi;

// private OpenAiChatOptions defaultOptions = OpenAiChatOptions.builder()
// .model(OpenAiApi.DEFAULT_CHAT_MODEL)
// .temperature(0.7)
// .build();

// private ToolCallingManager toolCallingManager;

// private ToolExecutionEligibilityPredicate toolExecutionEligibilityPredicate = new
// DefaultToolExecutionEligibilityPredicate();

// private RetryTemplate retryTemplate = RetryUtils.DEFAULT_RETRY_TEMPLATE;

// private ObservationRegistry observationRegistry = ObservationRegistry.NOOP;

// private Builder() {
// }

// public Builder openAiApi(OpenAiApi openAiApi) {
// this.openAiApi = openAiApi;
// return this;
// }

// public Builder defaultOptions(OpenAiChatOptions defaultOptions) {
// this.defaultOptions = defaultOptions;
// return this;
// }

// public Builder toolCallingManager(ToolCallingManager toolCallingManager) {
// this.toolCallingManager = toolCallingManager;
// return this;
// }

// public Builder toolExecutionEligibilityPredicate(
// ToolExecutionEligibilityPredicate toolExecutionEligibilityPredicate) {
// this.toolExecutionEligibilityPredicate = toolExecutionEligibilityPredicate;
// return this;
// }

// public Builder retryTemplate(RetryTemplate retryTemplate) {
// this.retryTemplate = retryTemplate;
// return this;
// }

// public Builder observationRegistry(ObservationRegistry observationRegistry) {
// this.observationRegistry = observationRegistry;
// return this;
// }

// public IncrementalToolCallChatModel build() {
// if (this.toolCallingManager != null) {
// return new IncrementalToolCallChatModel(this.openAiApi, this.defaultOptions,
// this.toolCallingManager,
// this.retryTemplate, this.observationRegistry, this.toolExecutionEligibilityPredicate);
// }
// return new IncrementalToolCallChatModel(this.openAiApi, this.defaultOptions,
// DEFAULT_TOOL_CALLING_MANAGER,
// this.retryTemplate, this.observationRegistry, this.toolExecutionEligibilityPredicate);
// }

// }

// }
// It can be done ,but I don't think that it's worth the effort.
