/*
 * Copyright 2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.cloud.ai.lynxe.tool;

/**
 * Interface for tools that can be terminated based on certain conditions Provides simple
 * termination capability check for tools
 */
public interface TerminableTool {

	/**
	 * Check if the tool can be terminated at the current state
	 * @return true if the tool can be terminated, false otherwise
	 */
	boolean canTerminate();

}
